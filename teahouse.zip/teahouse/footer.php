<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage TemplateMela
 * @since TemplateMela 1.0
 */
?>
<?php tmpmela_content_after(); ?>
</div>
<!-- .main-content-inner -->
</div>
<!-- .main_inner -->
</div>
<!-- #main -->
<?php tmpmela_footer_before(); ?>
<footer id="colophon" class="site-footer" role="contentinfo">
	<?php if ( is_active_sidebar( 'footer-top-left-widget-area' ) ) : ?>
		<div class="footer-top">
		 <div class="theme-container">
			<?php tmpmela_footer_inside(); ?>
			<?php get_sidebar('footer'); ?>
		</div>		
	   </div> 
	   <?php endif; ?>
	   		<?php if ( is_active_sidebar( 'footer-middle-widget-area' ) ) : ?>
			<div class="footer-middle">
				<div class="theme-container">
					<?php dynamic_sidebar('footer-middle-widget-area'); ?>
				</div>
			</div>
	<?php endif; ?>
		
					  
		<div class="footer-bottom">	
			<div class="theme-container">
			<div class="footer-bottom-menu-area">
				<?php if ( has_nav_menu('footer-menu') ) { ?>    
				<div class="footer-menu-links">
				<?php
							$tm_footer_menu=array(
							'menu' => esc_html__('TM Footer Navigation','teahouse'),
							'depth'=> 1,
							'echo' => false,
							'menu_class'      => 'footer-menu', 
							'container'       => '', 
							'container_class' => '', 
							'theme_location' => 'footer-menu'
							);
							echo wp_nav_menu($tm_footer_menu);				    
							?>
				</div><!-- #footer-menu-links -->
				<?php } ?>
			</div>
			<div class="footer-bottom-left">
				 <div class="site-info">  <?php echo esc_html__( 'Copyright', 'teahouse' ); ?> &copy; <?php echo esc_attr(date('Y')); ?> <a title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo esc_attr(stripslashes(get_option('tmpmela_footer_slog')));?>
						</a>
						<?php do_action( 'tmpmela_credits' ); ?>
					  </div>
					  </div>
			<?php if ( is_active_sidebar( 'footer-bottom-area' ) ) : ?>
			<div class="footer-bottom-right">
				<?php dynamic_sidebar('footer-bottom-area'); ?>
			</div>
			<?php endif; ?>
			</div>
    </div>
	
</footer>
<!-- #colophon -->
<?php tmpmela_footer_after(); ?>
</div>
<!-- #page -->
<?php tmpmela_go_top(); ?>
<?php tmpmela_get_widget('before-end-body-widget'); ?>
<?php wp_footer(); ?>
</body>
</html>
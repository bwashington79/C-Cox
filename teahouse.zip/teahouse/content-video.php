<?php
/**
 * The template for displaying posts in the Aside post format
 *
 * @package WordPress
 * @subpackage TemplateMela
 * @since TemplateMela 1.0
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <div class="entry-main-content">
 <?php if ( is_search() || !is_single()) : // Only display Excerpts for Search and not single pages ?>
	<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
 	<div class="entry-video">
       <?php
				the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'teahouse' ) );
				wp_link_pages( array(
					'before'      => '<div class="page-links"><span class="page-links-title">' . esc_attr__( 'Pages:', 'teahouse' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
				) );
			?>
	</div>
<?php endif; ?>
	<div class="sticky-tag <?php if(empty($postImage)): ?> non <?php endif; ?>">
		<?php tmpmela_sticky_post(); ?>
	</div>
		<div class="post-info <?php if(empty($postImage)): ?> non <?php endif; ?>"><!-- post-info -->
			<div class="entry-main-header post-header">
				<div class="blog-header"><!-- blog-header -->
						<?php 
							if( $post->post_title == '' ) : 
								$entry_meta_class = "empty-entry-header";
							else :
								$entry_meta_class = "";
							endif; ?>
						<header class="entry-header <?php echo esc_attr($entry_meta_class); ?>">					
								<h1 class="entry-title"> <a href="<?php esc_url(the_permalink()); ?>" rel="bookmark">
								<?php the_title(); ?>
								</a><?php tmpmela_sticky_post(); ?> </h1>					
						</header><!-- .entry-header -->	
						<div class="entry-content-date">
							<?php tmpmela_entry_date(); ?><?php tmpmela_author_link(); ?><?php tmpmela_comments_link(); ?>
						</div>
				</div><!-- blog-header -->	
		</div><!-- .entry-main-header -->
	<?php endif; ?>
	<div class="entry-content-other">		
		<?php if ( is_search() || !is_single()) : // Only display Excerpts for Search and not single pages ?>
			<div class="entry-summary">
				<div class="excerpt"> <?php echo tmpmela_posts_short_description(); ?> </div>
			</div><!-- .entry-summary -->
		</div><!-- post-info -->
			<?php else : ?>
			<div class="entry-main-header">
				<?php 
				if( $post->post_title == '' ) : 
				$entry_meta_class = "empty-entry-header";
				else :
				$entry_meta_class = "";
				endif; ?>
				<header class="entry-header <?php echo esc_attr($entry_meta_class); ?>">					
				<h1 class="entry-title"> 
				<?php the_title(); ?>
				<?php tmpmela_sticky_post(); ?> </h1>					
				</header><!-- .entry-header -->
				<div class="entry-content-inner"> 
					<div class="entry-meta-inner">    
						<div class="entry-meta">							  							
							<?php tmpmela_author_link(); ?>
							<?php edit_post_link( esc_html__( 'Edit', 'teahouse' ), '<span class="edit-link"><i class="fa fa-pencil"></i>', '</span>' ); ?>
							<?php tmpmela_comments_link(); ?>
							<?php tmpmela_tags_links(); ?>													
							<?php tmpmela_categories_links(); ?>	
							</div><!-- .entry-meta -->
						</div><!-- .entry-meta-inner -->
				</div><!-- .entry-content-inner -->
			</div><!-- .entry-main-header -->
			<div class="entry-content">
			<?php 
			 the_post_thumbnail('tmpmela-blog-posts-list');
			 $postImage = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
			 ?>
			 <?php the_content( wp_kses( __('Continue reading <span class="meta-nav">&rarr;</span>', 'teahouse' ),tmpmela_allowed_html())); ?>
			<?php wp_link_pages( array( 'before' => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'teahouse' ) . '</span>', 'after' => '</div>', 'link_before' => '<span>', 'link_after' => '</span>' ) ); ?>
			 <?php the_excerpt(); ?>
			</div><!-- .entry-content -->	
		<?php endif; ?>
	</div> <!-- entry-content-other -->	
	</div>
</article>
<!-- #post -->
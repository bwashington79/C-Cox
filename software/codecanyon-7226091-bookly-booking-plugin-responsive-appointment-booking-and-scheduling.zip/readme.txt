=== Bookly PRO – Appointment Booking and Scheduling Software System ===

Thank you for purchasing the Bookly PRO WordPress plugin.
We have developed this easy-to-use instrument especially for small businesses and
hope it will make the booking process for your clients as comfortable as never before. 

Please read about the installation procedure and plugin features in the online documentation:

https://www.booking-wp-plugin.com/documentation/


Wish your business prosper with Bookly!

Bookly Team
Email: support@bookly.info
=== Bookly PayPal Payments Standard Add-on ===

Thank you for purchasing Bookly PayPal Payments Standard add-on.

Please read about the installation procedure and add-on features in the online documentation:

https://support.booking-wp-plugin.com/hc/en-us/articles/115001959669-Bookly-PayPal-Payments-Standard-Add-on


Wish your business prosper with Bookly!

Ladela Interactive
Email: support@ladela.com